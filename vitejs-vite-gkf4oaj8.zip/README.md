# Elektro web (React + Vite + Tailwind + Router)

- Dev: `npm run dev`
- Build: `npm run build`
- Preview: `npm run preview`

Používa HashRouter (`#/` a `#/kalkulator`), aby fungoval aj na statickom hostingu (GH Pages). Tailwind je nastavený cez PostCSS.
